<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="alert alert-info">
                <strong>Selamat Datang di Sistem Informasi Perpustakaan</strong>
            </div>
        </div>
    </div>
    <div class="row">
        <!--colomn kedua-->
        <div class="col-sm-9 col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Daftar Buku</h3>
                </div>
                <div class="panel-body">
                    <table id="deskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th width="30%">Judul Buku</th>
                                <th>Nama Pengarang</th>
                                <th>Tahun Terbit</th>
                                <th>Loker Buku</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!--ambil data dari database, dan tampilkan kedalam tabel-->
                            <?php
                            require_once 'config/koneksi.php';
                            $database = new DatabaseConnection();
                            $pdo = $database->getConnection();

                            $sql = "SELECT * FROM buku";
                            $stmt = $pdo->prepare($sql);
                            $stmt->execute();
                            $nomor = 0;

                            while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                $nomor++;
                                ?>
                                <tr>
                                    <td><?= $nomor ?></td>
                                    <td><?= $data['judul_buku'] ?></td>
                                    <td><?= $data['nama_pengarang'] ?></td>
                                    <td><?= $data['tahun_terbit'] ?></td>
                                    <td><?= $data['loker_buku'] ?></td>
                                    <td><?= $data['status'] ?></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--akhir colomn kedua-->
        <div class="col-sm-3 col-xs-12">
            <!--Jika terjadi login error tampilkan pesan ini-->
            <?php if (isset($_GET['error'])) { ?>
                <div class="alert alert-danger">Maaf! Login Gagal, Coba Lagi..</div>
            <?php } ?>

            <?php if (isset($_SESSION['username'])) { ?>
                <div class="alert alert-info">
                    <strong>Welcome <?= $_SESSION['nama'] ?></strong>
                </div>
            <?php } else { ?>

                <div class="panel panel-success">
                    <div class="panel-heading">
                        <h3 class="panel-title">Masuk Ke Sistem</h3>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" action="proses_login.php" method="post">
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <input type="text" name="user" class="form-control input-sm"
                                           placeholder="Username" required="" autocomplete="off"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <input type="password" name="pwd" class="form-control input-sm"
                                           placeholder="Password" required="" autocomplete="off"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <button type="submit" name="login" value="login"
                                            class="btn btn-success btn-block"><span
                                                class="fa fa-unlock-alt"></span>
                                        Login Sistem
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            <?php } ?>
        </div>
    </div>
</div>
