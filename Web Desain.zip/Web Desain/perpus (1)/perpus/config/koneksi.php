<?php
class DatabaseConnection
{
    private $pdo;

    public function __construct()
    {
        $host = "localhost";
        $db_name = "dbperpus";
        $user = "postgres";
        $password = "3333";
        $port = "5432";

        try {
            $str = "pgsql:host={$host};port={$port};dbname={$db_name}";
            $this->pdo = new PDO($str, $user, $password);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            echo "Koneksi gagal: " . $e->getMessage();
        }
    }

    public function getConnection()
    {
        return $this->pdo;
    }

    public function closeConnection()
    {
        $this->pdo = null;
    }
}
?>
