<?php
$page = isset($_GET['page']) ? $_GET['page'] : "";
$aksi = isset($_GET['actions']) ? $_GET['actions'] : "";

// Seleksi page atau halaman yang dipilih oleh pengguna
if (empty($page)) {
    require 'beranda_adm.php';
} else {
    $file = "views/" . $page;
    if (!empty($aksi)) {
        $file .= "_" . $aksi;
    }
    $file .= ".php";

    if (file_exists($file)) {
        require $file;
    } else {
        require 'beranda.php';
    }
}
?>
