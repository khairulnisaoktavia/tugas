--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

-- Started on 2023-06-18 17:03:53

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dbperpus;
--
-- TOC entry 3349 (class 1262 OID 16518)
-- Name: dbperpus; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dbperpus WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Indonesia.1252';


ALTER DATABASE dbperpus OWNER TO postgres;

\connect dbperpus

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 215 (class 1259 OID 16520)
-- Name: buku; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buku (
    id integer NOT NULL,
    loker_buku character varying(25) NOT NULL,
    no_rak integer NOT NULL,
    no_laci integer NOT NULL,
    no_boks integer NOT NULL,
    judul_buku character varying(100) NOT NULL,
    nama_pengarang character varying(100) NOT NULL,
    tahun_terbit date NOT NULL,
    penerima character varying(50) NOT NULL,
    penerbit character varying(50) NOT NULL,
    status character varying(25) NOT NULL,
    keterangan character varying(100) NOT NULL
);


ALTER TABLE public.buku OWNER TO postgres;

--
-- TOC entry 214 (class 1259 OID 16519)
-- Name: buku_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.buku_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.buku_id_seq OWNER TO postgres;

--
-- TOC entry 3350 (class 0 OID 0)
-- Dependencies: 214
-- Name: buku_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.buku_id_seq OWNED BY public.buku.id;


--
-- TOC entry 217 (class 1259 OID 16538)
-- Name: login; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login (
    username character varying(25) NOT NULL,
    paswd character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    nama character varying(50) NOT NULL,
    level integer NOT NULL,
    ket character varying(50) NOT NULL
);


ALTER TABLE public.login OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16544)
-- Name: peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.peminjaman (
    judul_buku character varying(50) NOT NULL,
    peminjam character varying(50) NOT NULL,
    tgl_pinjam character varying(25),
    tgl_kembali character varying(25),
    lama_pinjam integer,
    keterangan character varying(100) NOT NULL,
    status character varying(20),
    id integer NOT NULL
);


ALTER TABLE public.peminjaman OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16543)
-- Name: peminjaman_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.peminjaman_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.peminjaman_id_seq OWNER TO postgres;

--
-- TOC entry 3351 (class 0 OID 0)
-- Dependencies: 218
-- Name: peminjaman_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.peminjaman_id_seq OWNED BY public.peminjaman.id;


--
-- TOC entry 216 (class 1259 OID 16533)
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    username character varying(25) NOT NULL,
    paswd character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    nama character varying(50) NOT NULL,
    level integer NOT NULL,
    ket character varying(50) NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- TOC entry 3186 (class 2604 OID 16523)
-- Name: buku id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buku ALTER COLUMN id SET DEFAULT nextval('public.buku_id_seq'::regclass);


--
-- TOC entry 3187 (class 2604 OID 16547)
-- Name: peminjaman id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peminjaman ALTER COLUMN id SET DEFAULT nextval('public.peminjaman_id_seq'::regclass);


--
-- TOC entry 3339 (class 0 OID 16520)
-- Dependencies: 215
-- Data for Name: buku; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (26, 'Buku Anak Anak', 3, 3, 12, 'mari belajar', 'rika hardina', '2019-06-06', 'Tk zahirA', 'Anlitera', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (27, 'Buku Anak Anak', 3, 3, 3, 'Sopan santun', 'Dwi hartono', '2019-01-01', 'TK ZAHIRA', 'Andi publisher', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (28, 'Buku Anak Anak', 4, 4, 123, 'Bermain dengan alat tradisional', 'Aan sutejo', '2019-01-03', 'Tk zahira', 'Gramedia', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (29, 'Buku Anak Anak', 5, 5, 5, 'Belajar membaca', 'Mizan', '2019-01-17', 'Tk zahira', 'Elexmedia', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (30, 'Buku Anak Anak', 6, 6, 6, 'Belajar berhitung', 'Tri Azhari', '2019-01-05', 'Tk zahira', 'Agro media', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (31, 'Buku Anak Anak', 7, 7, 7, 'Cara mudah membaca tanpa mengeja', 'irma yani', '2019-01-06', 'TK ZAHIRA', 'Gramdia', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (32, 'Buku Anak Anak', 8, 8, 8, 'belajar menebalkan', 'tri hawanda', '2018-12-30', 'Tk zahira', 'Andalas', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (33, 'Buku Anak Anak', 8, 8, 8, 'Belajar menulis huruf', 'joko susilo', '2019-01-13', 'Tk zahira', 'pustaka', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (34, 'Buku Anak Anak', 9, 9, 9, 'Mari bernyanyi bersama', 'Darwin', '2019-01-10', 'Tk zahira', 'Erlangga', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (35, 'Buku Anak Anak', 10, 10, 10, 'Makanan sehat', 'endang Mr', '2019-01-17', 'TK ZAHIRA', 'Swedia', 'Ada', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (36, 'Buku Anak Anak', 11, 111, 1, 'Huruf hijaiyah', 'reza hardian', '2019-01-09', 'Tk zahira', 'Elex media', 'Ada', '12346');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (37, 'Buku Anak Anak', 12, 12, 12, 'Mewarnai gambar', 'Irma yani', '2019-01-14', 'Tk zahira', 'Gria husada', 'Ada', '1234567');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (38, 'Buku Anak Anak', 13, 13, 13, 'Menggunting dan menempel', 'nuraini', '2019-01-12', 'Tk zahira', 'Gagas media', 'Ada', '1234567');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (39, 'Buku Anak Anak', 14, 14, 14, 'Mengenal Hewan', 'Astuti', '2019-01-06', 'Tk zahira', 'Aksara', 'Ada', '12345678');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (40, 'Buku Anak Anak', 15, 15, 15, '4 sehat 5 sempurna', 'tri aksara', '2019-01-02', 'Tk zahira', 'Elfata Andi', 'Ada', '12345678');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (41, 'Buku Anak Anak', 16, 16, 16, 'Lingkungan sehat', 'roro tri muji', '2019-01-09', 'Tk zahira', 'Andalas', 'Ada', '12345678');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (20, 'Buku Anak Anak', 22, 23, 24, 'Mari Belajar Gembira', 'Swedio', '2030-12-31', 'Herman', 'CV. Petir', 'Ada', '10');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (24, 'Buku Resep Masakan', 23, 221, 21, 'Masakan Tradisional Indonesia', 'Chef Juna', '2018-12-02', 'Ronaldo', 'UD. Skyscraper', 'Dipinjam', '20');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (25, 'Buku Anak Anak', 2, 2, 12, 'hidup sehat', 'muhammad iqbal', '2019-04-03', 'TK zahira', 'indie', 'Dipinjam', '12345');
INSERT INTO public.buku (id, loker_buku, no_rak, no_laci, no_boks, judul_buku, nama_pengarang, tahun_terbit, penerima, penerbit, status, keterangan) VALUES (22, 'Buku Anak Anak', 89, 898, 989, 'Majalah Genie', 'Mahkamah', '2019-12-31', 'Permata', 'CV. Badai', 'Ada', '12');


--
-- TOC entry 3341 (class 0 OID 16538)
-- Dependencies: 217
-- Data for Name: login; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.login (username, paswd, email, nama, level, ket) VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', 'nissa@gmail.com', 'Nissa', 1, 'Staff Perpustakaan');


--
-- TOC entry 3343 (class 0 OID 16544)
-- Dependencies: 219
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.peminjaman (judul_buku, peminjam, tgl_pinjam, tgl_kembali, lama_pinjam, keterangan, status, id) VALUES ('Kancil dan Buaya', 'Kamil', '2018-12-03', '2018-12-19', 16, 'Untuk Anak', NULL, 9);
INSERT INTO public.peminjaman (judul_buku, peminjam, tgl_pinjam, tgl_kembali, lama_pinjam, keterangan, status, id) VALUES ('hidup sehat', 'Yanto', '2019-01-15', '2019-01-17', 2, 'untuk anak', NULL, 10);
INSERT INTO public.peminjaman (judul_buku, peminjam, tgl_pinjam, tgl_kembali, lama_pinjam, keterangan, status, id) VALUES ('Masakan Tradisional Indonesia', 'a', '2017-12-31', '2017-12-31', 0, '2', 'Belum Kembali', 2);


--
-- TOC entry 3340 (class 0 OID 16533)
-- Dependencies: 216
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public."user" (username, paswd, email, nama, level, ket) VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', 'Nissa@gmail.com', 'Nissa', 1, 'Staff Perpustakaan');


--
-- TOC entry 3352 (class 0 OID 0)
-- Dependencies: 214
-- Name: buku_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.buku_id_seq', 5, true);


--
-- TOC entry 3353 (class 0 OID 0)
-- Dependencies: 218
-- Name: peminjaman_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.peminjaman_id_seq', 3, true);


--
-- TOC entry 3189 (class 2606 OID 16525)
-- Name: buku buku_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buku
    ADD CONSTRAINT buku_pkey PRIMARY KEY (id);


--
-- TOC entry 3193 (class 2606 OID 16542)
-- Name: login login_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login
    ADD CONSTRAINT login_pkey PRIMARY KEY (username);


--
-- TOC entry 3195 (class 2606 OID 16549)
-- Name: peminjaman peminjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.peminjaman
    ADD CONSTRAINT peminjaman_pkey PRIMARY KEY (id);


--
-- TOC entry 3191 (class 2606 OID 16537)
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (username);


-- Completed on 2023-06-18 17:03:54

--
-- PostgreSQL database dump complete
--

