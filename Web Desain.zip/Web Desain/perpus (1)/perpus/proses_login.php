<?php
// ambil data dari form login
$btn = $_POST['login'];
$user = $_POST['user'];
$pwd = $_POST['pwd'];
$pwd_enkripsi = md5($pwd);

// baca data ke database dengan label user
require_once 'config/koneksi.php';
$database = new DatabaseConnection();
$pdo = $database->getConnection();

$sql = "SELECT * FROM login WHERE username=:username AND paswd=:password";
$stmt = $pdo->prepare($sql);
$stmt->bindParam(':username', $user);
$stmt->bindParam(':password', $pwd_enkripsi);
$stmt->execute();

$jumlahdata = $stmt->rowCount();
if ($jumlahdata > 0) {
    $data = $stmt->fetch(PDO::FETCH_ASSOC); // ambil data dan konversi menjadi array
    session_start(); // aktifkan session wajib
    $_SESSION['username'] = $user;
    $_SESSION['idsesi'] = session_id();
    $_SESSION['level'] = $data['level'];
    $_SESSION['nama'] = $data['nama'];
    $_SESSION['ket'] = $data['ket'];
    $_SESSION['email'] = $data['email'];
    // pindahkan ke halaman index
    header("location:index_admin.php", true);
} else {
    echo "<script>window.location.assign('index.php?error=yes');</script>";
}
