<?php
//membuat query untuk hapus data
$database = new DatabaseConnection();
$pdo = $database->getConnection();
$sql="DELETE FROM buku WHERE id ='".$_GET['id']."'";
$query=$pdo->query($sql);
if($query){
    echo"<script> window.location.assign('?page=buku&actions=tampil');</script>";
}else{
    echo"<script> alert ('Maaf !!! Data Tidak Berhasil Dihapus') window.location.assign('?page=buku&actions=tampil');</scripr>";
}

