<?php
//membuat query untuk hapus data
$database = new DatabaseConnection();
$pdo = $database->getConnection();
$sql="DELETE FROM peminjaman WHERE id ='".$_GET['id']."'";
$query=$pdo->query($sql);
if($query){
    echo"<script> window.location.assign('?page=peminjaman&actions=tampil');</script>";
}else{
    echo"<script> alert ('Maaf !!! Data Tidak Berhasil Dihapus') window.location.assign('?page=peminjaman&actions=tampil');</scripr>";
}

