<?php
$database = new DatabaseConnection();
$pdo = $database->getConnection();
$judulbuku=$_GET['judulbuku'];
$ambil=  $pdo ->query("SELECT * FROM buku WHERE judul_buku ='$judulbuku'") ;
$data= $ambil->fetch((PDO::FETCH_ASSOC));
?>

<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title">Tambah Data Pinjaman Buku</h3>
                </div>
                <div class="panel-body">
                    <!--membuat form untuk tambah data-->
                    <form class="form-horizontal" action="" method="post">
                        <div class="form-group">
                            <label for="judulbuku" class="col-sm-3 control-label">Judul Buku</label>
                            <div class="col-sm-9">
								<input type="text" name="judulbuku" value="<?=$data['judul_buku']?>" class="form-control" id="inputEmail3" placeholder="Nomor Perkara" readonly="true">
                            </div>
                        </div>

						<div class="form-group">
                            <label for="peminjam" class="col-sm-3 control-label">Nama Peminjam</label>
                            <div class="col-sm-9">
                                <input type="text" name="peminjam" class="form-control" id="inputEmail3" placeholder="Nama Peminjam">
                            </div>
                        </div>

						<div class="form-group">
                            <label for="tglPinjam" class="col-sm-3 control-label">Tanggal Pinjam</label>
                            <div class="col-sm-3">
                                <input type="date" name="tglPinjam" class="form-control" id="inputEmail3" placeholder="Tanggal Pinjam">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="ket" class="col-sm-3 control-label">Lama Peminjaman</label>
                            <div class="col-sm-9">
                                <input type="text" name="hitung" class="form-control" id="inputEmail3" placeholder="Berapa hari dipinjam">
                            </div>
                        </div>

						<div class="form-group">
                            <label for="ket" class="col-sm-3 control-label">Keterangan</label>
                            <div class="col-sm-9">
                                <input type="text" name="ket" class="form-control" id="inputEmail3" placeholder="Keterangan">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-9">
                                <button type="submit" class="btn btn-success">
                                    <span class="fa fa-save"></span> Simpan Peminjaman</button>
                            </div>
                        </div>
                    </form>


                </div>
                <div class="panel-footer">
                    <a href="?page=buku&actions=tampil" class="btn btn-danger btn-sm">
                        Kembali Ke Data Buku
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //Ambil data dari form
    $noPerkara = $_POST['judulbuku'];
    $peminjam = $_POST['peminjam'];
    $lmapeminjaman = $_POST['hitung'];
    $tglPinjam = $_POST['tglPinjam'];
    $ket = $_POST['ket'];
    
    $today = $tglPinjam;  // Tanggal saat ini
    $daysToAdd = $lmapeminjaman;  // Jumlah hari yang ingin ditambahkan
    
    $futureDate = date('Y-m-d', strtotime($today) + ($daysToAdd * 24 * 60 * 60));

    //buat sql
    $sql = "INSERT INTO peminjaman (judul_buku, peminjam, tgl_pinjam, tgl_kembali, lama_pinjam, status, keterangan) VALUES (?, ?, ?, ?, ?, 'Belum Kembali', ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$noPerkara, $peminjam, $tglPinjam, $futureDate, $lmapeminjaman, $ket]);
    
    $sqlBuku = "UPDATE buku SET status='Dipinjam' WHERE judul_buku=?";
    $stmtBuku = $pdo->prepare($sqlBuku);
    $stmtBuku->execute([$noPerkara]);
    
    if ($stmt && $stmtBuku) {
        echo "<script>window.location.assign('?page=peminjaman&actions=tampil');</script>";
    } else {
        echo "<script>alert('Simpan Data Gagal');</script>";
    }
}

?>
